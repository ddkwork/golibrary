package mypan

import (
	"errors"
	"fmt"

	"github.com/ddkwork/librarygo/src/mylog"
	"github.com/ddkwork/librarygo/src/mypan/RefreshToken"
	"github.com/ddkwork/librarygo/src/stream"
	"github.com/ddkwork/librarygo/src/stream/tool/cmd"
	"github.com/libsgh/PanIndex/module"
	"github.com/libsgh/PanIndex/pan"
	"os"
	"path/filepath"
	//"qrcode-token/qrcode"
	//"qrcode-token/qrcode/model"
	//"qrcode-token/util/vjson"
)

//go get github.com/libsgh/PanIndex@main
//go install github.com/libsgh/PanIndex@main
//PanIndex

type (
	MyPan struct {
		account     module.Account
		choose      pan.Pan
		aliyundrive pan.Pan
		cloud189    pan.Pan
		yun139      pan.Pan
		googledrive pan.Pan
	}
)

func GetRefreshToken() string                               { return RefreshToken.Get() }
func GitConeDev(url string) (packedName string, ok bool)    { return gitConeWithBranch(url, "dev") }
func GitConeMain(url string) (packedName string, ok bool)   { return gitConeWithBranch(url, "main") }
func GitConeMaster(url string) (packedName string, ok bool) { return gitConeWithBranch(url, "master") }
func GitCone(url string) (packedName string, ok bool)       { return gitConeWithBranch(url, "") }
func gitConeWithBranch(url, branch string) (packedName string, ok bool) {
	if branch != "" {
		branch = "-b " + branch
	}
	name := filepath.Base(url)
	os.RemoveAll(name)
	packedName = name + ".tar.zst"
	os.Remove(packedName)
	run, err := cmd.RunArgs("git clone --recursive", branch, url, name)
	if !mylog.Error(err) {
		return
	}
	mylog.Success("result", run)
	s, err := cmd.RunArgs("tar -I pzstd -cvf", packedName, name)
	if !mylog.Error(err) {
		return
	}
	mylog.Success("result", s)
	ok = true
	return
}

// go install github.com/gngpp/qrcode-token/tree/main@main
// to refesh token
func Aliyundrive() *MyPan {
	return &MyPan{
		account: module.Account{},
		choose:  &pan.Ali{},
	}
}
func Cloud189() *MyPan {
	return &MyPan{
		account: module.Account{},
		choose:  &pan.Cloud189{},
	}
}
func Yun139() *MyPan {
	return &MyPan{
		account: module.Account{},
		choose:  &pan.Yun139{},
	}
}
func Googledrive() *MyPan {
	return &MyPan{
		account: module.Account{},
		choose:  &pan.GoogleDrive{},
	}
}

func (m *MyPan) SetAccount(User, Password, RefreshToken string) *MyPan {
	m.account = module.Account{
		Id:             "",
		Name:           "",
		Mode:           "",
		User:           User,
		Password:       Password,
		RefreshToken:   RefreshToken,
		AccessToken:    "",
		RedirectUri:    "",
		ApiUrl:         "",
		RootId:         "root",
		SiteId:         "",
		Seq:            0,
		FilesCount:     0,
		Status:         0,
		CookieStatus:   0,
		TimeSpan:       "",
		LastOpTime:     "",
		SyncDir:        "",
		SyncChild:      0,
		SyncCron:       "",
		DownTransfer:   0,
		TransferDomain: "",
		CachePolicy:    "",
		ExpireTimeSpan: 0,
		Host:           "",
	}
	return m
}
func (m *MyPan) IsLogin() bool {
	total, _ := m.getSpaceSzie()
	return total > 0
}
func (m *MyPan) UploadFiles(path string) (ok bool) {
	refreshToken, err := m.authLogin()
	if !mylog.Error(err) {
		return
	}
	mylog.Trace("refresh_token", refreshToken)
	mylog.Struct(pan.Alis)
	b := stream.NewReadFile(path)
	files := []*module.UploadInfo{{
		FileName:    filepath.Base(path),
		FileSize:    int64(b.Len()),
		ContentType: "application/octet-stream",
		Content:     b.Bytes(),
	}}
	kind := m.getKind()
	switch kind.(type) {
	case *pan.Ali:
		fmt.Println(m.choose.(*pan.Ali).UploadFiles(m.account, "root", files, true))
	case *pan.Cloud189:
		fmt.Println(m.choose.(*pan.Cloud189).UploadFiles(m.account, "root", files, true))
	case *pan.Yun139:
		fmt.Println(m.choose.(*pan.Yun139).UploadFiles(m.account, "root", files, true))
	case *pan.GoogleDrive:
		fmt.Println(m.choose.(*pan.GoogleDrive).UploadFiles(m.account, "root", files, true))
	}
	return true
}

func (m *MyPan) getSpaceSzie() (int64, int64) {
	kind := m.getKind()
	switch kind.(type) {
	case *pan.Ali:
		return m.choose.(*pan.Ali).GetSpaceSzie(m.account)
	case *pan.Cloud189:
		return m.choose.(*pan.Cloud189).GetSpaceSzie(m.account)
	case *pan.Yun139:
		return m.choose.(*pan.Yun139).GetSpaceSzie(m.account)
	case *pan.GoogleDrive:
		return m.choose.(*pan.GoogleDrive).GetSpaceSzie(m.account)
	}
	return 0, 0
}
func (m *MyPan) GetDownloadUrl(fileId string) (string, error) {
	//fileId--------------------------- 62f6123001f395209f534fa2aa7721ef39880f2a
	//search by name? for linux etc
	kind := m.getKind()
	switch kind.(type) {
	case *pan.Ali:
		return m.choose.(*pan.Ali).GetDownloadUrl(m.account, fileId)
	case *pan.Cloud189:
		return m.choose.(*pan.Cloud189).GetDownloadUrl(m.account, fileId)
	case *pan.Yun139:
		return m.choose.(*pan.Yun139).GetDownloadUrl(m.account, fileId)
	case *pan.GoogleDrive:
		return m.choose.(*pan.GoogleDrive).GetDownloadUrl(m.account, fileId)
	}
	return "", errors.New("not handle getKind")
}
func (m *MyPan) getKind() any {
	if _, ok := m.choose.(*pan.Ali); ok {
		return m.choose.(*pan.Ali)
	}
	if _, ok := m.choose.(*pan.Cloud189); ok {
		return m.choose.(*pan.Cloud189)
	}
	if _, ok := m.choose.(*pan.Yun139); ok {
		return m.choose.(*pan.Yun139)
	}
	if _, ok := m.choose.(*pan.GoogleDrive); ok {
		return m.choose.(*pan.GoogleDrive)
	}
	return nil
}
func (m *MyPan) authLogin() (string, error) {
	kind := m.getKind()
	switch kind.(type) {
	case *pan.Ali:
		return m.choose.(*pan.Ali).AuthLogin(&m.account)
	case *pan.Cloud189:
		return m.choose.(*pan.Cloud189).AuthLogin(&m.account)
	case *pan.Yun139:
		return m.choose.(*pan.Yun139).AuthLogin(&m.account)
	case *pan.GoogleDrive:
		return m.choose.(*pan.GoogleDrive).AuthLogin(&m.account)
	}
	return "", errors.New("not handle getKind")
}

//
//func (m *MyPan) Files(account module.Account, fileId, path, sortColumn, sortOrder string) ([]module.FileNode, error) {
//	//TODO implement me
//	panic("implement me")
//}
//func (m *MyPan) File(account module.Account, fileId, path string) (module.FileNode, error) {
//	//TODO implement me
//	panic("implement me")
//}
//func (m *MyPan) Rename(account module.Account, fileId, name string) (bool, interface{}, error) {
//	//TODO implement me
//	panic("implement me")
//}
//func (m *MyPan) Remove(account module.Account, fileId string) (bool, interface{}, error) {
//	//TODO implement me
//	panic("implement me")
//}
//func (m *MyPan) Mkdir(account module.Account, parentFileId, name string) (bool, interface{}, error) {
//	//TODO implement me
//	panic("implement me")
//}
//func (m *MyPan) Move(account module.Account, fileId, targetFileId string, overwrite bool) (bool, interface{}, error) {
//	//TODO implement me
//	panic("implement me")
//}
//func (m *MyPan) Copy(account module.Account, fileId, targetFileId string, overwrite bool) (bool, interface{}, error) {
//	//TODO implement me
//	panic("implement me")
//}
