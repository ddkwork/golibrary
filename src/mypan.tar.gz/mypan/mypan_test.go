package mypan_test

import (
	"fmt"
	"github.com/ddkwork/librarygo/src/mypan"
	"github.com/ddkwork/librarygo/src/stream/tool/cmd"
	"testing"
)

//git clone -b dev https://github.com/libsgh/PanIndex
//http://127.0.0.1:5238/admin/
//PanIndex


//go:generate go test .

func TestAll(t *testing.T) {
	all := []string{
		"https://github.com/goki/gide",
		"https://github.com/goki/gi",
		"https://github.com/goki/vgpu",
		"https://github.com/goki/pi",
		"https://github.com/goki/prof",
		"https://github.com/goki/ki",
		"https://github.com/goki/mat32",
		"https://github.com/goki/grid",
		"https://github.com/goki/go-difflib",
		"https://github.com/goki/vulkan",
		"https://github.com/goki/vci",
		"https://github.com/goki/freetype",
		"https://github.com/goki/grail",
		"https://github.com/goki/gopix",
		"https://github.com/goki/gotopy",
		"https://github.com/goki/goki.github.io",
		"https://github.com/goki/glide",
		"https://github.com/goki/stringer",
		"https://github.com/goki/gopy_old",
	}
	for _, s := range all {
		packedName, ok := mypan.GitCone(s)
		if !ok {
			return
		}
		Aliyundrive := mypan.Aliyundrive().SetAccount("", "", "7a7cc9b3ddce4eb1bd7715ed12e19380")
		if !Aliyundrive.UploadFiles(packedName) {
			return
		}
	}
	p := "https://sdk.lunarg.com/sdk/download/1.3.216.0/windows/VulkanSDK-1.3.216.0-Installer.exe"
	cmd.Run("wget " + p)
	if !mypan.Aliyundrive().UploadFiles("VulkanSDK-1.3.216.0-Installer.exe") {
		return
	}
}

func TestAliYunDrive(t *testing.T) {
	// println(mypan.GetRefreshToken())
	//packedName, ok := mypan.GitConeDev(`https://github.com/HyperDbg/HyperDbg`)
	packedName, ok := mypan.GitCone(`https://github.com/aquasecurity/go-dep-parser`)
	if !ok {
		return
	}
	Aliyundrive := mypan.Aliyundrive().SetAccount("", "", "7a7cc9b3ddce4eb1bd7715ed12e19380")
	if !Aliyundrive.UploadFiles(packedName) {
		return
	}
	return
	if !Aliyundrive.UploadFiles("D:\\codespace\\workspace\\src\\librarygo\\src\\mypan\\cmd\\a.go") {
		return
	}
	fmt.Println(Aliyundrive.GetDownloadUrl("a.go"))
}

func TestCloud189(t *testing.T) {
	return
	Cloud189 := mypan.Cloud189().SetAccount("", "", "")
	if !Cloud189.UploadFiles("D:\\codespace\\workspace\\src\\librarygo\\src\\mypan\\cmd\\a.go") {
		return
	}
	fmt.Println(Cloud189.GetDownloadUrl("a.go"))
}

func TestYun139(t *testing.T) {
	return
	mypan.Yun139().SetAccount("", "", "").
		UploadFiles("D:\\codespace\\workspace\\src\\librarygo\\src\\mypan\\cmd\\a.go")
}

func TestGoogledrive(t *testing.T) {
	return
	mypan.Googledrive().SetAccount("", "", "").
		UploadFiles("D:\\codespace\\workspace\\src\\librarygo\\src\\mypan\\cmd\\a.go")
}
