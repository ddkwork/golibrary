package mycheck

import (
	"fmt"
	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/widget"
	"github.com/ddkwork/librarygo/src/fynelib/canvasobjectapi"
	"github.com/ddkwork/librarygo/src/mycheck/internal/cyclicimport"
	"github.com/ddkwork/librarygo/src/tuitable"
	"github.com/stretchr/testify/assert"
	"runtime"
	"runtime/debug"
	"testing"
)

func Assert(t *testing.T) *assert.Assertions            { return assert.New(t) }
func Error(err any) bool                                { return Default.Error(err) }
func Error2(_ any, err error) (ok bool)                 { return Default.Error2(nil, err) }
func Body() string                                      { return Default.Body() }
func CanvasObject(window fyne.Window) fyne.CanvasObject { return Default.CanvasObject(window) }
func ShowError() {
	w := fyne.CurrentApp().NewWindow("Error Show")
	w.SetContent(CanvasObject(w))
	w.CenterOnScreen()
	w.Resize(fyne.NewSize(900, 600))
	w.Show()
}

type (
	Interface interface {
		Error(err any) bool
		Error2(_, err error) bool
		Body() string
		canvasobjectapi.Interface
	}
	row struct {
		key   string
		value string
	}
	object struct {
		row
		rows []row
		body string
		err  any
	}
)

func (o *object) CanvasObject(window fyne.Window) fyne.CanvasObject { return o.Table() }
func (o *object) Rows() []row {
	if len(o.rows) > 0 {
		o.rows = o.rows[:0]
	}
	o.rows = append(o.rows,
		row{key: "reason", value: o.Reason(o.err)},
		row{key: "fn", value: Caller()},
		row{key: "time", value: o.Time()},
		row{key: "goroutine", value: o.Goroutine()},
		row{key: "stack", value: o.Stack()},
	)
	return o.rows
}

func (o *object) Table() *widget.Table {
	rows := o.Rows()
	//t := &widget.Table{ //SetColumnWidth was error if do this
	t := widget.NewTable(
		func() (int, int) { return len(rows), 2 },
		func() fyne.CanvasObject { return widget.NewLabel("") },
		func(id widget.TableCellID, canvasObject fyne.CanvasObject) {
			switch id.Col {
			case 0:
				canvasObject.(*widget.Label).SetText(rows[id.Row].key)
			case 1:
				canvasObject.(*widget.Label).SetText(rows[id.Row].value)
			}
		},
	)
	t.SetColumnWidth(0, 110)
	t.SetColumnWidth(1, 430)
	return t
}

var (
	Default = New()
	log     = cyclicimport.New()
)

func New() Interface {
	return &object{
		row: row{
			key:   "",
			value: "",
		},
		rows: make([]row, 0),
		body: "",
		err:  nil,
	}
}
func (o *object) Body() string               { return o.body }
func (r *row) Time() string                  { return log.GetTimeNowString() }
func (r *row) Goroutine() (goroutine string) { return fmt.Sprint(runtime.NumGoroutine()) }
func (r *row) Stack() string                 { return string(debug.Stack()) }
func (r *row) Reason(err any) string {
	switch err.(type) {
	case error:
		return err.(error).Error()
	case string:
		return err.(string)
	}
	return ""
}

func (o *object) Error(err any) bool {
	o.err = err
	if err == nil {
		return true
	}
	return o.setErrorInfo()
}

func (o *object) Error2(_, err error) (ok bool) {
	o.err = err
	if err == nil {
		return true
	}
	return o.setErrorInfo()
}

func (o *object) setErrorInfo() (ok bool) {
	t := tuitable.NewTable()
	for _, r := range o.Rows() {
		t.AddRow(r.key, r.value)
	}
	o.body = t.Body()
	log.LogError(o.body)
	return false
}
