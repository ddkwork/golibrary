package main

import (
	"testing"
)

func TestCheck(t *testing.T) {
	check := mycheck.New()
	check.Error("Π√√√√√√√√√√√√√Π√√√√√√√√√√√√√Π√√√√√√√√√√√√√Π√√√√√√√√√√√√√Π√√√√√√√√√√√√√")
}
