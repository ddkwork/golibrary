package main

import (
	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/app"
	"fyne.io/fyne/v2/widget"
	"github.com/ddkwork/librarygo/src/fynelib/fyneTheme"
)

func main() {
	a := app.NewWithID("com.rows.app")
	a.SetIcon(nil)
	fyneTheme.Dark()
	w := a.NewWindow("app")
	w.Resize(fyne.NewSize(640, 480))
	w.SetMaster()
	w.CenterOnScreen()
	w.SetContent(widget.NewButton("测试中文", func() {
		mycheck.Error(111111111)
		mycheck.ShowError()
	}))
	w.ShowAndRun()
}
